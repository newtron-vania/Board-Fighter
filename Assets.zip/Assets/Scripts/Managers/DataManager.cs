using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public interface ILoader<Key, Value>
{
    Dictionary<Key, Value> MakeDict();
}

public class DataManager
{
    public Dictionary<int, Datas.MapData> mapDict = new Dictionary<int, Datas.MapData>();
    public void Init()
    {
        SetMapDatas();
    }

    public void SetMapDatas()
    {
        Dictionary<int, Datas.MapDataDTO> mapDTODatas = LoadJson<Datas.MapDTODict, int, Datas.MapDataDTO>("MapData").MakeDict();
        foreach (var data in mapDTODatas)
        {
            mapDict[data.Key] = data.Value.DtoToMap();
        }
    }

    Loader LoadJson<Loader, Key, Value>(string path) where Loader : ILoader<Key, Value>
    {
        TextAsset textAsset = Managers.Resource.Load<TextAsset>($"Json/{path}");
        return JsonUtility.FromJson<Loader>(textAsset.text);
    }

}