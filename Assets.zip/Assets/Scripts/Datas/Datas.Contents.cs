using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.TextCore.Text;

namespace Datas
{
    [System.Serializable]
    public class Character
    {
        public Define.Class _class;
        public Tile pos;
    }
    
    
    [System.Serializable]
    public class MapDataDTO // the data model for database
    {
        public int mapid;
        public GridRow[] gridMap;
        public List<Character> myCharacter;
        public List<Character> enemyCharacter;
        
        public MapData DtoToMap()
        {
            MapData map = new MapData()
            {
                mapid =  this.mapid,
                gridMap = toTwoDimArray(),
                myCharacter = this.myCharacter,
                enemyCharacter = this.enemyCharacter
            };
            return map;
        }
        
        public int[,] toTwoDimArray()
        {
            int col = gridMap.GetLength(0);
            int row = gridMap[0].rows.GetLength(0);
            int[,] twoDimArray = new int[col, row];
            for (int i = 0; i < col; i++)
            {
                for (int j = 0; j < row; j++)
                {
                    twoDimArray[i, j] = gridMap[i].rows[j];
                }
            }

            return twoDimArray;
        }
    }
    
    public class MapDTODict : ILoader<int, MapDataDTO>
    {
        public List<MapDataDTO> mapdatadtos = new List<MapDataDTO>();
        public Dictionary<int, MapDataDTO> MakeDict()
        {
            Dictionary<int, MapDataDTO> dict = new Dictionary<int, MapDataDTO>();
            foreach (MapDataDTO data in mapdatadtos)
            {
                Debug.Log($"mapid : {data.mapid}");
                dict.Add(data.mapid, data);
            }
            return dict;
        }
    }

    [System.Serializable]
    public class GridRow
    {
        public int[] rows;
    }
    
    public class MapData
    {
        public int mapid;
        public int[,] gridMap;
        public List<Character> myCharacter;
        public List<Character> enemyCharacter;
    }
    

    
}
