using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Tile : ICloneable
{
    [SerializeField]
    private int x = 0;
    [SerializeField]
    private int y = 0;
    
    public int X
    {
        get { return x; }
    }

    public int Y
    {
        get { return y; }
    }

    public bool hasObstacle;
    public Tile parent;

    public int gCost = 0;
    public int hCost = 0;

    public int fCost
    {
        get { return gCost + hCost; }
    }
    public Tile(int x, int y, bool hasObstacle = false)
    {
        this.x = x;
        this.y = y;
        this.hasObstacle = hasObstacle;
    }

    public int getDistance(Tile a, Tile b)
    {
        return a - b;
    }

    public static int operator -(Tile a, Tile b)
    {
        return Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);
    }

    public static bool operator ==(Tile a, Tile b)
    {
        if (a.x == b.x && a.y == b.y)
        {
            return true;
        }

        return false;
    }
    
    public static bool operator !=(Tile a, Tile b)
    {
        if (a.x != b.x || a.y != b.y)
        {
            return true;
        }

        return false;
    }
    public object Clone()
    {
        return new Tile(x, y, hasObstacle);
    }
}
