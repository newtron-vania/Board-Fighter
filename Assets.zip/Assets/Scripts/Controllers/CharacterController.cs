using System;
using System.Collections;
using System.Collections.Generic;
using AI;
using Unity.VisualScripting;
using UnityEngine;

public class CharacterController : MonoBehaviour
{
    public Tile _pos;
    private MoveType _moveType;
    private AttackType _attackType;
    private AttackStyle _attackStyle;

    private Animator _animator;

    public Define.WorldObject _worldObject = Define.WorldObject.Unknown;

    private void Start()
    {
        _moveType = GetComponent<MoveType>();
        _attackType = GetComponent<AttackType>();
        _attackType.Damage = GetComponent<Stat>().Damage;
        _attackStyle = GetComponent<AttackStyle>();
        _animator = GetComponent<Animator>();
    }

    public void Action(HashSet<GameObject> enemies)
    {
        List<CharacterController> enemiesList = new List<CharacterController>();
        foreach (var mEnemyCharacter in enemies)
        {
            enemiesList.Add(mEnemyCharacter.GetComponent<CharacterController>());
        }
        if(FindInRangedTarget(enemiesList, out List<CharacterController> targets))
        {
            foreach (var UPPER in targets)
            {
                Debug.Log($"Target : {UPPER}");
            }
            Attack(targets);
        }
        else
        {
            Move(enemiesList);
        }
        
    }


    public bool Move(List<CharacterController> targets)
    {
        Tile next = null;
        Debug.Log($"{this.transform.name} Move!");
        if (_moveType.Move(_pos, out next, targets))
        {
            _animator.Play("Move");
            Vector3 dir = new Vector3(next.Y - _pos.Y, -(next.X - _pos.X), 0);
            Vector2 nextVec = this.transform.position + dir;
            if (dir.x < 0)
            {
                this.transform.localScale = new Vector3(-1,0,0);
            }
            else if (dir.x > 0)
            {
                this.transform.localScale = new Vector3(1, 0, 0);
            }

            GameManager.Instance().GetMap[_pos.X, _pos.Y].hasObstacle = false;
            GameManager.Instance().GetMap[next.X, next.Y].hasObstacle = true;
            _pos = next;
            Debug.Log($"{this.transform.name} next is ({_pos.X} , {_pos.Y})!");
            Debug.Log($"{this.transform.name} next Vector is {nextVec}");

            StartCoroutine(Moving(this.transform.position, nextVec, _lerpTime));
        }
        
        return false;
    }

    private float _lerpTime = 0.5f;
    IEnumerator Moving(Vector3 current, Vector3 next, float time)
    {
        float elapsedTime = 0.0f;
        this.transform.position = current;
        while (elapsedTime < time)
        {
            elapsedTime += Time.fixedDeltaTime;
            this.transform.position = Vector3.Lerp(current, next, elapsedTime / time);
            yield return new WaitForFixedUpdate();
        }

        this.transform.position = next;
        _animator.Play("Idle");
        yield return null;
    }

    public bool Attack(List<CharacterController> targets)
    {
        Debug.Log($"{this.transform.name} Attack!");
        _animator.Play("Attack");
        _attackType.Attack(targets);
        return false;
    }

    public bool FindInRangedTarget(List<CharacterController> enemies, out List<CharacterController> targets)
    {
        Debug.Log("Detectiong! ");
        if (_attackStyle.IsInRange(_pos, enemies, out targets))
        {
            return true;
        }
        return false;
    }
}
