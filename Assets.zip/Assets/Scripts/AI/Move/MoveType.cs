using System.Collections;
using System.Collections.Generic;
using AI;
using Unity.VisualScripting;
using UnityEngine;

public abstract class MoveType : MonoBehaviour
{
    public Pathfinding _pathfinding;

    private void Start()
    {
        _pathfinding = new AstarPathFinding_v2();
    }
    public abstract bool Move(Tile start, out Tile next, List<CharacterController> enemies);
    
    
}
