using System.Collections;
using System.Collections.Generic;
using AI;
using UnityEngine;

public class Walk : MoveType
{

    public override bool Move(Tile start, out Tile next, List<CharacterController> enemies)
    {
        next = null;
        if (enemies.Count <= 0)
        {
            
            return false;
        }

        next = FindPath(start, enemies);
        return true;
    }
    
    private Tile FindPath(Tile start, List<CharacterController> enemies)
    {
        List<Tile> shortestPath = new List<Tile>();
        foreach (var enemy in enemies)
        {
            List<Tile> path = _pathfinding.GetNextPath(start, enemy._pos);
            if (shortestPath.Count <= 0 || path.Count < shortestPath.Count)
            {
                shortestPath = path;
            }
        }

        if (shortestPath.Count <= 0)
        {
            return null;
        }
        
        return shortestPath[0];
    }
}
