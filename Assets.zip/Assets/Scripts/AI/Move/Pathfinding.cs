using System.Collections.Generic;

namespace AI
{
    public interface Pathfinding
    {
        public List<Tile> GetNextPath(Tile start, Tile target, bool ignoreObstacle = false);

        public Tile[,] InitializeGrid();
    }
}